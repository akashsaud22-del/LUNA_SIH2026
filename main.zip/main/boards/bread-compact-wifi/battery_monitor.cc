// ============================================================
// LUNA Battery Monitor — battery_monitor.cc — SIMPLIFIED
//
// Place this file in: main/boards/bread-compact-wifi/
// Auto-compiled — no CMakeLists.txt edit needed.
// ============================================================

#include "battery_monitor.h"
#include "config.h"   // for BATTERY_ADC_GPIO (documentation only)

#include <esp_log.h>
#include <esp_adc/adc_oneshot.h>
#include <esp_adc/adc_cali.h>
#include <esp_adc/adc_cali_scheme.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#define TAG "BatteryMonitor"

// ============================================================
// ADC configuration
// GPIO1 on ESP32-S3 = ADC1 Channel 0  (matches BATTERY_ADC_GPIO)
//
// RATIO CALIBRATION (DO NOT CHANGE without re-measuring):
//   Measured: multimeter battery = 3.60V, sensor pin = 0.684V
//   ratio = 3.60 / 0.684 ≈ 5.26
// ============================================================
#define BATTERY_ADC_CHANNEL     ADC_CHANNEL_0
#define BATTERY_ADC_UNIT        ADC_UNIT_1
#define BATTERY_ADC_ATTEN       ADC_ATTEN_DB_12
#define BATTERY_DIVIDER_RATIO   5.26f
#define BATTERY_READ_SAMPLES    10
#define BATTERY_READ_INTERVAL_US (30 * 1000 * 1000) // 30 seconds

static adc_oneshot_unit_handle_t adc_handle_ = nullptr;
static adc_cali_handle_t cali_handle_ = nullptr;
static bool cali_enabled_ = false;

struct VoltagePoint { float voltage; int percent; };

static const VoltagePoint VOLTAGE_TABLE[] = {
    { 4.20f, 100 },
    { 4.15f,  95 },
    { 4.10f,  90 },
    { 4.05f,  85 },
    { 4.00f,  80 },
    { 3.95f,  75 },
    { 3.90f,  70 },
    { 3.85f,  65 },
    { 3.80f,  60 },
    { 3.75f,  50 },
    { 3.70f,  35 },
    { 3.65f,  25 },
    { 3.60f,  20 },
    { 3.58f,  15 },
    { 3.55f,  10 },
    { 3.52f,   5 },
    { 3.50f,   0 },
};
static const int TABLE_SIZE = sizeof(VOLTAGE_TABLE) / sizeof(VOLTAGE_TABLE[0]);

void BatteryMonitor::TimerCallback(void* arg) {
    auto* self = static_cast<BatteryMonitor*>(arg);

    // Only sample while Idle — Listening/Speaking/AI-processing
    // skip this cycle entirely, leaving percent_ untouched so the
    // OLED keeps showing the last valid reading.
    if (self->is_idle_fn_ && !self->is_idle_fn_()) {
        ESP_LOGI(TAG, "Skipping read — not Idle (keeping last value: %d%%)", self->percent_);
        return;
    }
    self->UpdateAndNotify();
}

void BatteryMonitor::Init(BatteryCallback callback, std::function<bool()> is_idle_fn) {
    callback_ = callback;
    is_idle_fn_ = is_idle_fn;

    adc_oneshot_unit_init_cfg_t unit_cfg = {};
    unit_cfg.unit_id = BATTERY_ADC_UNIT;
    esp_err_t err = adc_oneshot_new_unit(&unit_cfg, &adc_handle_);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to init ADC unit: %d", err);
        return;
    }

    adc_oneshot_chan_cfg_t chan_cfg = {};
    chan_cfg.atten = BATTERY_ADC_ATTEN;
    chan_cfg.bitwidth = ADC_BITWIDTH_DEFAULT;
    ESP_ERROR_CHECK(adc_oneshot_config_channel(adc_handle_, BATTERY_ADC_CHANNEL, &chan_cfg));

#if ADC_CALI_SCHEME_CURVE_FITTING_SUPPORTED
    {
        adc_cali_curve_fitting_config_t cali_cfg = {};
        cali_cfg.unit_id = BATTERY_ADC_UNIT;
        cali_cfg.chan = BATTERY_ADC_CHANNEL;
        cali_cfg.atten = BATTERY_ADC_ATTEN;
        cali_cfg.bitwidth = ADC_BITWIDTH_DEFAULT;
        cali_enabled_ = (adc_cali_create_scheme_curve_fitting(&cali_cfg, &cali_handle_) == ESP_OK);
    }
#elif ADC_CALI_SCHEME_LINE_FITTING_SUPPORTED
    {
        adc_cali_line_fitting_config_t cali_cfg = {};
        cali_cfg.unit_id = BATTERY_ADC_UNIT;
        cali_cfg.atten = BATTERY_ADC_ATTEN;
        cali_cfg.bitwidth = ADC_BITWIDTH_DEFAULT;
        cali_enabled_ = (adc_cali_create_scheme_line_fitting(&cali_cfg, &cali_handle_) == ESP_OK);
    }
#endif

    ESP_LOGI(TAG, "ADC ready. Calibration: %s", cali_enabled_ ? "enabled" : "disabled");

    // First reading always happens immediately, regardless of idle
    // state (there's no device state yet this early in boot).
    UpdateAndNotify();

    esp_timer_create_args_t timer_args = {};
    timer_args.callback = TimerCallback;
    timer_args.arg = this;
    timer_args.dispatch_method = ESP_TIMER_TASK;
    timer_args.name = "battery_timer";

    esp_timer_handle_t timer = nullptr;
    ESP_ERROR_CHECK(esp_timer_create(&timer_args, &timer));
    ESP_ERROR_CHECK(esp_timer_start_periodic(timer, BATTERY_READ_INTERVAL_US));

    ESP_LOGI(TAG, "Battery monitor started: %.2fV  %d%%", voltage_, percent_);
}

float BatteryMonitor::ReadVoltage() {
    if (!adc_handle_) return voltage_;

    long total = 0;
    for (int i = 0; i < BATTERY_READ_SAMPLES; i++) {
        int raw = 0;
        adc_oneshot_read(adc_handle_, BATTERY_ADC_CHANNEL, &raw);
        total += raw;
        vTaskDelay(pdMS_TO_TICKS(2));
    }
    int avg_raw = (int)(total / BATTERY_READ_SAMPLES);

    float mv;
    if (cali_enabled_ && cali_handle_) {
        int cal_mv = 0;
        adc_cali_raw_to_voltage(cali_handle_, avg_raw, &cal_mv);
        mv = (float)cal_mv;
    } else {
        mv = (avg_raw / 4095.0f) * 3300.0f;
    }

    float battery_voltage = (mv / 1000.0f) * BATTERY_DIVIDER_RATIO;
    ESP_LOGI(TAG, "ADC raw=%d  sensor=%.3fV  battery(calc)=%.2fV",
        avg_raw, mv / 1000.0f, battery_voltage);
    return battery_voltage;
}

int BatteryMonitor::VoltageToPercent(float voltage) {
    if (voltage >= VOLTAGE_TABLE[0].voltage) return 100;
    if (voltage <= VOLTAGE_TABLE[TABLE_SIZE - 1].voltage) return 0;

    for (int i = 0; i < TABLE_SIZE - 1; i++) {
        float v_high = VOLTAGE_TABLE[i].voltage;
        float v_low  = VOLTAGE_TABLE[i + 1].voltage;
        if (voltage <= v_high && voltage >= v_low) {
            int p_high = VOLTAGE_TABLE[i].percent;
            int p_low  = VOLTAGE_TABLE[i + 1].percent;
            float ratio = (voltage - v_low) / (v_high - v_low);
            int percent = p_low + (int)(ratio * (p_high - p_low));
            percent = ((percent + 2) / 5) * 5;
            if (percent > 100) percent = 100;
            if (percent < 0) percent = 0;
            return percent;
        }
    }
    return 0;
}

// ============================================================
// UpdateAndNotify — read, convert, and notify if changed.
// No zones, no hysteresis — just a plain percent value now.
// ============================================================
void BatteryMonitor::UpdateAndNotify() {
    float new_voltage = ReadVoltage();
    int new_percent = VoltageToPercent(new_voltage);

    bool changed = (new_percent != percent_) || first_read_;
    voltage_ = new_voltage;
    percent_ = new_percent;
    first_read_ = false;

    ESP_LOGI(TAG, "Battery: %.2fV -> %d%%", voltage_, percent_);

    if (changed && callback_) {
        callback_(percent_);
    }
}

void BatteryMonitor::ReadNow() {
    UpdateAndNotify();
}