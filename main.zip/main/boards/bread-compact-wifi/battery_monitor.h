#pragma once

// ============================================================
// LUNA Battery Monitor — SIMPLIFIED
//
// New behavior (per Sugam's simplified spec):
//   - No muting, no feature restrictions at any battery level.
//   - ADC is only sampled while the device is Idle (skipped
//     entirely during Listening/Speaking, where amplifier
//     current draw causes false low readings).
//   - The last valid percent is kept on screen during a
//     conversation; it updates again once back at Idle.
//   - No zone/hysteresis system anymore — just a single
//     percent value and a simple "is it below 10%" check,
//     decided by the board code (compact_wifi_board.cc) which
//     also owns the 5s-on/1min-repeat warning timing.
// ============================================================

#include <functional>

// Callback type — fires whenever a NEW reading is taken
// (i.e. only while Idle), with the freshly computed percent.
using BatteryCallback = std::function<void(int percent)>;

class BatteryMonitor {
public:
    // Initialize ADC, take an initial reading, start the periodic timer.
    // is_idle_fn is called every cycle to decide whether to actually
    // sample the ADC this time (only proceeds when it returns true).
    void Init(BatteryCallback callback, std::function<bool()> is_idle_fn);

    // Force an immediate read regardless of idle state — used only
    // for the very first reading at boot, before any device state
    // exists yet.
    void ReadNow();

    // Last known values (kept stable between Idle readings)
    int GetPercent() const { return percent_; }
    float GetVoltage() const { return voltage_; }

private:
    BatteryCallback callback_ = nullptr;
    std::function<bool()> is_idle_fn_ = nullptr;

    int percent_ = 100;
    float voltage_ = 4.20f;
    bool first_read_ = true;

    float ReadVoltage();
    int VoltageToPercent(float voltage);
    void UpdateAndNotify();

    static void TimerCallback(void* arg);
};