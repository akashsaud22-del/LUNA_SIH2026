// ============================================================
// LUNA RGB Status LED — rgb_status_led.cc
// Place in: main/boards/bread-compact-wifi/
// ============================================================

#include "rgb_status_led.h"
#include "application.h"
#include "device_state.h"
#include <esp_log.h>

#define TAG "RgbStatusLed"

// ============================================================
// CONSTRUCTOR
// ============================================================
RgbStatusLed::RgbStatusLed(gpio_num_t red_pin,
                             gpio_num_t green_pin,
                             gpio_num_t blue_pin)
    : red_pin_(red_pin), green_pin_(green_pin), blue_pin_(blue_pin) {

    ESP_LOGI(TAG, "Initializing RGB LED (COMMON ANODE): R=GPIO%d G=GPIO%d B=GPIO%d",
        (int)red_pin_, (int)green_pin_, (int)blue_pin_);

    // Configure each pin as simple push-pull output.
    // Common-anode LED: HIGH = off, LOW = on. Default to HIGH (off) at boot.
    auto configure_pin = [](gpio_num_t pin) {
        gpio_reset_pin(pin);
        gpio_set_direction(pin, GPIO_MODE_OUTPUT);
        gpio_set_level(pin, 1);   // 1 = OFF for common-anode
    };
    configure_pin(red_pin_);
    configure_pin(green_pin_);
    configure_pin(blue_pin_);

    // Quick flash all 3 colors at boot to verify wiring.
    // LOW (0) = ON for this common-anode LED.
    vTaskDelay(pdMS_TO_TICKS(100));
    gpio_set_level(red_pin_, 0);   vTaskDelay(pdMS_TO_TICKS(300));
    gpio_set_level(red_pin_, 1);
    gpio_set_level(green_pin_, 0); vTaskDelay(pdMS_TO_TICKS(300));
    gpio_set_level(green_pin_, 1);
    gpio_set_level(blue_pin_, 0);  vTaskDelay(pdMS_TO_TICKS(300));
    gpio_set_level(blue_pin_, 1);

    ESP_LOGI(TAG, "RGB LED startup test complete");

    // Create blink timer
    esp_timer_create_args_t timer_args = {};
    timer_args.callback        = BlinkTimerCallback;
    timer_args.arg             = this;
    timer_args.dispatch_method = ESP_TIMER_TASK;
    timer_args.name            = "rgb_blink";
    ESP_ERROR_CHECK(esp_timer_create(&timer_args, &blink_timer_));
}

// ============================================================
// DESTRUCTOR
// ============================================================
RgbStatusLed::~RgbStatusLed() {
    if (blink_timer_) {
        esp_timer_stop(blink_timer_);
        esp_timer_delete(blink_timer_);
    }
    // Common-anode: HIGH = off
    gpio_set_level(red_pin_, 1);
    gpio_set_level(green_pin_, 1);
    gpio_set_level(blue_pin_, 1);
}

// ============================================================
// LOW LEVEL PIN CONTROL
// ============================================================
// ============================================================
// LOW LEVEL PIN CONTROL
//
// COMMON ANODE LED: the shared (long) pin connects to +3.3V.
// Each color leg lights up when pulled LOW, and turns off when
// driven HIGH. So here we invert: r/g/b=true (color should be
// ON) writes 0 to the pin; r/g/b=false (color OFF) writes 1.
// ============================================================
void RgbStatusLed::SetPins(bool r, bool g, bool b) {
    gpio_set_level(red_pin_,   r ? 0 : 1);
    gpio_set_level(green_pin_, g ? 0 : 1);
    gpio_set_level(blue_pin_,  b ? 0 : 1);
    ESP_LOGD(TAG, "Pins → R=%d G=%d B=%d (logical on/off, common-anode inverted)", r?1:0, g?1:0, b?1:0);
}

void RgbStatusLed::TurnOn() {
    std::lock_guard<std::mutex> lock(mutex_);
    esp_timer_stop(blink_timer_);
    blink_phase_ = false;
    if (!battery_low_) {
        SetPins(show_red_, show_green_, show_blue_);
    }
}

void RgbStatusLed::TurnOff() {
    std::lock_guard<std::mutex> lock(mutex_);
    esp_timer_stop(blink_timer_);
    blink_phase_ = false;
    SetPins(false, false, false);
}

void RgbStatusLed::StartBlink(int interval_ms) {
    std::lock_guard<std::mutex> lock(mutex_);
    esp_timer_stop(blink_timer_);
    blink_phase_ = true;
    if (!battery_low_) {
        SetPins(show_red_, show_green_, show_blue_);
    }
    esp_timer_start_periodic(blink_timer_, (uint64_t)interval_ms * 1000);
}

void RgbStatusLed::StopBlink() {
    std::lock_guard<std::mutex> lock(mutex_);
    esp_timer_stop(blink_timer_);
    blink_phase_ = false;
    SetPins(false, false, false);
}

// ============================================================
// BLINK TIMER — toggle using instance variable, not static
// (static variable caused all instances to share state)
// ============================================================
void RgbStatusLed::BlinkTimerCallback(void* arg) {
    auto* self = static_cast<RgbStatusLed*>(arg);
    std::lock_guard<std::mutex> lock(self->mutex_);
    if (self->battery_low_) {
        self->SetPins(false, false, false);
        return;
    }
    self->blink_phase_ = !self->blink_phase_;
    if (self->blink_phase_) {
        self->SetPins(self->show_red_, self->show_green_, self->show_blue_);
    } else {
        self->SetPins(false, false, false);
    }
}

// ============================================================
// SET BATTERY LOW
// ============================================================
void RgbStatusLed::SetBatteryLow(bool low) {
    battery_low_ = low;
    if (low) {
        std::lock_guard<std::mutex> lock(mutex_);
        esp_timer_stop(blink_timer_);
        SetPins(false, false, false);
        ESP_LOGW(TAG, "Battery ≤20%% → LED off");
    } else {
        ESP_LOGI(TAG, "Battery OK → resuming LED");
        OnStateChanged();
    }
}

// ============================================================
// ON STATE CHANGED — main behavior
// ============================================================
void RgbStatusLed::OnStateChanged() {
    if (battery_low_) return;

    auto& app = Application::GetInstance();
    auto state = app.GetDeviceState();

    ESP_LOGI(TAG, "State changed → %d", (int)state);

    switch (state) {
        case kDeviceStateListening:
        case kDeviceStateAudioTesting:
            show_red_ = true; show_green_ = false; show_blue_ = false;
            TurnOn();
            ESP_LOGI(TAG, "→ RED (listening)");
            break;

        case kDeviceStateSpeaking:
            show_red_ = false; show_green_ = true; show_blue_ = false;
            TurnOn();
            ESP_LOGI(TAG, "→ GREEN (speaking)");
            break;

        case kDeviceStateIdle:
            show_red_ = false; show_green_ = false; show_blue_ = true;
            TurnOn();
            ESP_LOGI(TAG, "→ BLUE (idle)");
            break;

        case kDeviceStateConnecting:
        case kDeviceStateActivating:
            show_red_ = false; show_green_ = false; show_blue_ = true;
            TurnOn();
            break;

        case kDeviceStateStarting:
            show_red_ = false; show_green_ = false; show_blue_ = true;
            StartBlink(100);
            break;

        case kDeviceStateWifiConfiguring:
            show_red_ = false; show_green_ = false; show_blue_ = true;
            StartBlink(500);
            break;

        case kDeviceStateUpgrading:
            show_red_ = false; show_green_ = true; show_blue_ = false;
            StartBlink(100);
            break;

        case kDeviceStateFatalError:
            show_red_ = true; show_green_ = false; show_blue_ = false;
            StartBlink(200);
            break;

        default:
            TurnOff();
            break;
    }
}