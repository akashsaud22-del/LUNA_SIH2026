// ============================================================
// LUNA AI Chatbot — compact_wifi_board.cc — FINAL FIXED
// Nepal Time: UTC+5:45
// NTP starts when WiFi connects via NetworkEventCallback
// ============================================================

#include "wifi_board.h"
#include "codecs/no_audio_codec.h"
#include "display/oled_display.h"
#include "system_reset.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "mcp_server.h"
#include "lamp_controller.h"
#include "led/single_led.h"
#include "rgb_status_led.h"
#include "assets/lang_config.h"
#include "battery_monitor.h"
#include "settings.h"

#include <esp_log.h>
#include <driver/i2c_master.h>
#include <esp_lcd_panel_ops.h>
#include <esp_lcd_panel_vendor.h>
#include <esp_netif_sntp.h>
#include <esp_timer.h>
#include <time.h>
#include <algorithm>

#ifdef SH1106
#include <esp_lcd_panel_sh1106.h>
#endif

#define TAG "CompactWifiBoard"

class CompactWifiBoard : public WifiBoard {
private:
    i2c_master_bus_handle_t display_i2c_bus_;
    esp_lcd_panel_io_handle_t panel_io_ = nullptr;
    esp_lcd_panel_handle_t panel_ = nullptr;
    Display* display_ = nullptr;
    bool ntp_started_ = false;

    Button boot_button_;
    Button touch_button_;
    Button volume_up_button_;
    Button volume_down_button_;
    Button encoder_sw_button_;

    // LUNA Sleep Mode button — GPIO12 ("SELECT BTN"). Hold 2s to
    // toggle between Normal Mode and Sleep Mode. GPIO13 (the
    // encoder push, encoder_sw_button_ above) is completely
    // unchanged and still cycles the 3 screens in both modes.
    Button sleep_button_;
    bool is_sleeping_ = false;

    // LUNA TTP223 touch sensors — active_high=true (TTP223 outputs
    // HIGH when touched). Both are simple tap-only buttons (no
    // long-press) — the earlier "Sad → Crying" long-press design
    // caused a freeze/hang bug, so sensor 2 was simplified to a
    // single Angry expression, mirroring sensor 1's exact pattern.
    Button touch_happy_button_;
    Button touch_sad_button_;  // now drives the "Angry" reaction (tap-only)
    esp_timer_handle_t happy_reaction_timer_ = nullptr;
    esp_timer_handle_t angry_reaction_timer_ = nullptr;

    // LUNA battery monitoring
    BatteryMonitor battery_monitor_;
    int saved_volume_ = 100;

    // LUNA simplified battery monitor: tracks the last time the
    // low-battery toast was shown, so it repeats every 60s while
    // battery stays below 10% (and resets once it recovers above).
    int64_t last_low_battery_warning_ms_ = 0;

    // LUNA: timestamp of the last sleep-button press (entering OR
    // waking). Battery sampling is skipped for 10 seconds after
    // either transition, since toggling mic/speaker/WiFi power
    // mode right around that moment can cause a brief ADC reading
    // glitch that doesn't reflect the real battery level.
    int64_t last_sleep_button_press_ms_ = 0;

    // LUNA RGB LED — direct object (not a pointer, never null)
    RgbStatusLed rgb_led_{RGB_RED_GPIO, RGB_GREEN_GPIO, RGB_BLUE_GPIO};

    OledDisplay* GetOled() {
        return static_cast<OledDisplay*>(display_);
    }

    // ============================================================
    // Start NTP — only called after WiFi connects
    // ============================================================
    void StartNTP() {
        if (ntp_started_) return;
        ntp_started_ = true;

        ESP_LOGI(TAG, "WiFi connected — starting NTP for Nepal time");

        // Nepal Standard Time = UTC+5:45
        // POSIX format: negative offset means east of UTC
        setenv("TZ", "UTC-5:45", 1);
        tzset();

        // Init SNTP with single server
        esp_sntp_config_t cfg = ESP_NETIF_SNTP_DEFAULT_CONFIG("pool.ntp.org");
        cfg.sync_cb = [](struct timeval* tv) {
            // Reapply after sync to be safe
            setenv("TZ", "UTC-5:45", 1);
            tzset();

            time_t now;
            struct tm t;
            time(&now);
            localtime_r(&now, &t);
            char buf[32];
            strftime(buf, sizeof(buf), "%H:%M:%S %Z", &t);
            ESP_LOGI("NTP", "Time synced! Nepal: %s", buf);
        };
        esp_netif_sntp_init(&cfg);
    }

    void InitializeDisplayI2c() {
        i2c_master_bus_config_t bus_config = {
            .i2c_port = (i2c_port_t)0,
            .sda_io_num = DISPLAY_SDA_PIN,
            .scl_io_num = DISPLAY_SCL_PIN,
            .clk_source = I2C_CLK_SRC_DEFAULT,
            .glitch_ignore_cnt = 7,
            .intr_priority = 0,
            .trans_queue_depth = 0,
            .flags = { .enable_internal_pullup = 1 },
        };
        ESP_ERROR_CHECK(i2c_new_master_bus(&bus_config, &display_i2c_bus_));
    }

    void InitializeSsd1306Display() {
        esp_lcd_panel_io_i2c_config_t io_config = {
            .dev_addr = 0x3C,
            .on_color_trans_done = nullptr,
            .user_ctx = nullptr,
            .control_phase_bytes = 1,
            .dc_bit_offset = 6,
            .lcd_cmd_bits = 8,
            .lcd_param_bits = 8,
            .flags = { .dc_low_on_data = 0, .disable_control_phase = 0 },
            .scl_speed_hz = 400 * 1000,
        };
        ESP_ERROR_CHECK(esp_lcd_new_panel_io_i2c_v2(
            display_i2c_bus_, &io_config, &panel_io_));

        esp_lcd_panel_dev_config_t panel_config = {};
        panel_config.reset_gpio_num = -1;
        panel_config.bits_per_pixel = 1;
        esp_lcd_panel_ssd1306_config_t ssd1306_config = {
            .height = static_cast<uint8_t>(DISPLAY_HEIGHT),
        };
        panel_config.vendor_config = &ssd1306_config;

#ifdef SH1106
        ESP_ERROR_CHECK(esp_lcd_new_panel_sh1106(panel_io_, &panel_config, &panel_));
#else
        ESP_ERROR_CHECK(esp_lcd_new_panel_ssd1306(panel_io_, &panel_config, &panel_));
#endif
        ESP_ERROR_CHECK(esp_lcd_panel_reset(panel_));
        if (esp_lcd_panel_init(panel_) != ESP_OK) {
            ESP_LOGE(TAG, "Failed to initialize display");
            display_ = new NoDisplay();
            return;
        }
        ESP_ERROR_CHECK(esp_lcd_panel_invert_color(panel_, false));
        ESP_ERROR_CHECK(esp_lcd_panel_disp_on_off(panel_, true));
        display_ = new OledDisplay(panel_io_, panel_,
            DISPLAY_WIDTH, DISPLAY_HEIGHT,
            DISPLAY_MIRROR_X, DISPLAY_MIRROR_Y);
        ESP_LOGI(TAG, "Display initialized");
    }

    void InitializeButtons() {
        // Boot button — WiFi config or chat toggle
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            app.ToggleChatState();
        });

        // Mode button (GPIO4) — toggle text mode
        touch_button_.OnClick([this]() {
            if (auto oled = GetOled()) oled->ToggleTextMode();
        });

        // Encoder SW (GPIO13) — push to toggle text mode
        encoder_sw_button_.OnClick([this]() {
            if (auto oled = GetOled()) oled->ToggleTextMode();
        });

        // Encoder CLK (GPIO40) — scroll down / long = vol up
        volume_up_button_.OnClick([this]() {
            if (auto oled = GetOled()) oled->ScrollDown();
        });
        volume_up_button_.OnLongPress([this]() {
            auto codec = GetAudioCodec();
            auto vol = std::min(codec->output_volume() + 10, 100);
            codec->SetOutputVolume(vol);
            // Save to NVS so it persists after restart
            Settings settings("luna", true);
            settings.SetInt("volume", vol);
            saved_volume_ = vol;
            GetDisplay()->ShowNotification(
                Lang::Strings::VOLUME + std::to_string(vol));
        });

        // Encoder DT (GPIO39) — scroll up / long = vol down
        volume_down_button_.OnClick([this]() {
            if (auto oled = GetOled()) oled->ScrollUp();
        });
        volume_down_button_.OnLongPress([this]() {
            auto codec = GetAudioCodec();
            auto vol = std::max(codec->output_volume() - 10, 0);
            codec->SetOutputVolume(vol);
            // Save to NVS so it persists after restart
            Settings settings("luna", true);
            settings.SetInt("volume", vol);
            saved_volume_ = vol;
            GetDisplay()->ShowNotification(
                Lang::Strings::VOLUME + std::to_string(vol));
        });
    }

    // ============================================================
    // LUNA Touch Sensors (TTP223 x2)
    //
    // Both sensors are completely ignored while the device is
    // actively Listening or Speaking (per spec) — IsBusyTalking()
    // checks this once and is reused by both handlers.
    //
    // Happy sensor (tap):
    //   PressDown → show Happy face + happy sound
    //   A one-shot timer ends the reaction after ~2.5s
    //
    // Sad/Crying sensor (press and hold):
    //   PressDown  → show Sad face + sad sound immediately
    //   LongPress  → escalates to Crying face + crying sound
    //                (fires automatically at the 3s mark if still held)
    //   PressUp    → ends the reaction immediately, whether it was
    //                still Sad (released early) or had become Crying
    // ============================================================
    bool IsBusyTalking() {
        auto state = Application::GetInstance().GetDeviceState();
        return state == kDeviceStateListening || state == kDeviceStateSpeaking;
    }

    void InitializeTouchSensors() {
        // Reusable one-shot timers for each reaction's auto-return to idle
        esp_timer_create_args_t happy_timer_args = {};
        happy_timer_args.callback = [](void* arg) {
            auto* self = static_cast<CompactWifiBoard*>(arg);
            if (auto oled = self->GetOled()) oled->EndTouchReaction();
        };
        happy_timer_args.arg = this;
        happy_timer_args.dispatch_method = ESP_TIMER_TASK;
        happy_timer_args.name = "happy_reaction";
        ESP_ERROR_CHECK(esp_timer_create(&happy_timer_args, &happy_reaction_timer_));

        esp_timer_create_args_t angry_timer_args = {};
        angry_timer_args.callback = [](void* arg) {
            auto* self = static_cast<CompactWifiBoard*>(arg);
            if (auto oled = self->GetOled()) oled->EndTouchReaction();
        };
        angry_timer_args.arg = this;
        angry_timer_args.dispatch_method = ESP_TIMER_TASK;
        angry_timer_args.name = "angry_reaction";
        ESP_ERROR_CHECK(esp_timer_create(&angry_timer_args, &angry_reaction_timer_));

        // ---- Sensor 1: HAPPY ----
        touch_happy_button_.OnPressDown([this]() {
            if (IsBusyTalking()) return;
            // Defer to the main app task — PlaySound() does real (blocking)
            // OGG decode work inline, and running that directly inside the
            // button library's callback can stall its polling task long
            // enough to miss subsequent press/release events or hang.
            Application::GetInstance().Schedule([this]() {
                if (auto oled = GetOled()) {
                    oled->ShowTouchReaction(FaceState::Happy);
                }
                // No sound in Sleep Mode — visual reaction only
                if (!is_sleeping_) {
                    Application::GetInstance().PlaySound(Lang::Sounds::OGG_SUCCESS);
                }
            });

            // Auto-return to idle after ~2.5 seconds
            esp_timer_stop(happy_reaction_timer_); // safe even if not running
            esp_timer_start_once(happy_reaction_timer_, 2500 * 1000);
        });

        // ---- Sensor 2: ANGRY ----
        // Simple tap only — same pattern as Happy. No long-press,
        // no escalation. The earlier "Sad → Crying" long-press
        // design caused a freeze bug and has been removed entirely.
        touch_sad_button_.OnPressDown([this]() {
            if (IsBusyTalking()) return;
            Application::GetInstance().Schedule([this]() {
                if (auto oled = GetOled()) {
                    oled->ShowTouchReaction(FaceState::Angry);
                }
                // No sound in Sleep Mode — visual reaction only
                if (!is_sleeping_) {
                    Application::GetInstance().PlaySound(Lang::Sounds::OGG_EXCLAMATION);
                }
            });

            // Auto-return to idle after ~2.5 seconds
            esp_timer_stop(angry_reaction_timer_); // safe even if not running
            esp_timer_start_once(angry_reaction_timer_, 2500 * 1000);
        });
    }

    // ============================================================
    // LUNA Sleep Mode
    //
    // GPIO12 (Select button), held 2 seconds, toggles between:
    //
    //   Normal Mode: WiFi normal power, wake word active, mic/
    //                speaker active, sounds play normally.
    //
    //   Sleep Mode:  WiFi switched to LOW_POWER (stays connected,
    //                minimal draw — a full disconnect isn't safely
    //                exposed at the board level), wake word OFF,
    //                mic OFF, speaker OFF, no sounds play at all
    //                (including touch sensor reactions — visual
    //                only). The 3-screen cycle (GPIO13, unchanged)
    //                keeps working normally in both modes; the
    //                WiFi icon just shows a small "cut" line.
    //
    // The ONLY way out of Sleep Mode is the same 2s hold again —
    // wake word is intentionally completely disabled while asleep.
    // ============================================================
    void InitializeSleepButton() {
        sleep_button_.OnLongPress([this]() {
            if (is_sleeping_) {
                // Always allowed to wake up, regardless of state
                WakeUp();
            } else {
                // Only allowed to enter sleep while genuinely Idle
                // (blue LED, not actively listening/speaking). This
                // removes the need to forcibly abort an in-flight
                // conversation, which was the root cause of the
                // wake-word and battery-reading glitches.
                if (Application::GetInstance().GetDeviceState() == kDeviceStateIdle) {
                    EnterSleep();
                } else {
                    ESP_LOGI(TAG, "Sleep button ignored — not Idle (still listening/speaking)");
                    if (auto oled = GetOled()) {
                        oled->ShowSleepMessage("Please wait until idle");
                    }
                }
            }
        });
    }

    void EnterSleep() {
        if (is_sleeping_) return;
        is_sleeping_ = true;
        last_sleep_button_press_ms_ = esp_timer_get_time() / 1000;

        // Defer to the main app task — touching shared audio/display
        // state directly from the button task risks stalling button
        // polling (same root cause as the earlier touch-sensor freeze).
        //
        // NOTE: we no longer need to AbortSpeaking()/StopListening()
        // here — the sleep button now only triggers EnterSleep() when
        // the device is ALREADY confirmed Idle (checked at the call
        // site in InitializeSleepButton), so there's nothing in
        // flight to abort. This removed the root cause of both the
        // wake-word and battery-glitch bugs.
        Application::GetInstance().Schedule([this]() {
            auto& app = Application::GetInstance();

            // WiFi → low power (kept connected, but minimal radio use)
            SetPowerSaveLevel(PowerSaveLevel::LOW_POWER);

            // Wake word, mic, speaker all OFF
            app.GetAudioService().EnableWakeWordDetection(false);
            auto codec = GetAudioCodec();
            codec->EnableInput(false);
            codec->EnableOutput(false);

            // RGB LED off while sleeping
            rgb_led_.SetBatteryLow(true); // reuses the existing "force off" path

            // WiFi icon shows a small cut line + sleep message —
            // using our own toast (ShowNotification's label is never
            // actually visible in our custom 3-screen layout)
            if (auto oled = GetOled()) {
                oled->SetWifiCut(true);
                oled->ShowSleepMessage("Going to Sleep...");
            }

            ESP_LOGI(TAG, "Entered Sleep Mode");
        });
    }

    void WakeUp() {
        if (!is_sleeping_) return;
        is_sleeping_ = false;
        last_sleep_button_press_ms_ = esp_timer_get_time() / 1000;

        Application::GetInstance().Schedule([this]() {
            auto& app = Application::GetInstance();

            // WiFi → back to normal power
            SetPowerSaveLevel(PowerSaveLevel::PERFORMANCE);

            // Re-enable codec input/output FIRST, so the hardware path
            // is live before we ask the wake-word engine to start
            // reading from it again.
            auto codec = GetAudioCodec();
            codec->EnableInput(true);
            codec->EnableOutput(true);

            // SetDeviceState(Idle) runs its own normal transition
            // (clears chat, resets emotion, etc.) — this also calls
            // EnableWakeWordDetection(true) internally, but we call it
            // AGAIN explicitly right after, since it's idempotent and
            // this guarantees it's the very last word on the matter,
            // regardless of internal ordering inside the state machine.
            app.SetDeviceState(kDeviceStateIdle);
            app.GetAudioService().EnableWakeWordDetection(true);

            // RGB LED resumes normal Idle/Listening/Speaking behavior
            rgb_led_.SetBatteryLow(false);

            if (auto oled = GetOled()) {
                oled->SetWifiCut(false);
                oled->ShowSleepMessage("Waking Luna...");
            }

            ESP_LOGI(TAG, "Woke up from Sleep Mode");
        });
    }

    void InitializeTools() {
        static LampController lamp(LAMP_GPIO);
    }

    // ============================================================
    // LUNA Battery Monitor — SIMPLIFIED
    //
    // - No feature restrictions at any battery level: WiFi, AI,
    //   microphone, speaker, display, and RGB LED all keep working
    //   normally no matter the battery percentage.
    // - ADC is only sampled while Idle (BatteryMonitor itself
    //   checks this via the is_idle_fn_ passed to Init() below) —
    //   this avoids false low readings caused by amplifier current
    //   draw while Listening/Speaking. The OLED simply keeps
    //   showing the last valid percent until the next Idle reading.
    // - Below 10%: show a small "Battery Low!" toast for 5 seconds,
    //   repeating every 60 seconds for as long as it stays below 10%.
    // ============================================================
    void InitializeBattery() {
        battery_monitor_.Init(
            [this](int percent) {
                ESP_LOGW("Battery", "%d%%", percent);

                bool low = (percent < 10);
                bool show_warning = false;

                if (low) {
                    int64_t now_ms = esp_timer_get_time() / 1000;
                    if (now_ms - last_low_battery_warning_ms_ >= 60000) {
                        show_warning = true;
                        last_low_battery_warning_ms_ = now_ms;
                    }
                } else {
                    // Back above 10% — reset so a future dip warns right away
                    last_low_battery_warning_ms_ = 0;
                }

                if (auto oled = GetOled()) {
                    oled->UpdateBattery(percent, show_warning);
                }
            },
            [this]() {
                // is_idle_fn — only sample while truly Idle, AND at
                // least 10 seconds after the last sleep-button press
                // (entering or waking), to avoid a glitched ADC
                // reading right as mic/speaker/WiFi power mode toggle.
                if (Application::GetInstance().GetDeviceState() != kDeviceStateIdle) {
                    return false;
                }
                int64_t now_ms = esp_timer_get_time() / 1000;
                if (now_ms - last_sleep_button_press_ms_ < 10000) {
                    return false;
                }
                return true;
            });
    }

public:
    CompactWifiBoard() :
        boot_button_(BOOT_BUTTON_GPIO),
        touch_button_(TOUCH_BUTTON_GPIO),
        volume_up_button_(VOLUME_UP_BUTTON_GPIO),
        volume_down_button_(VOLUME_DOWN_BUTTON_GPIO),
        encoder_sw_button_(ENCODER_SW_GPIO),
        sleep_button_(SLEEP_BUTTON_GPIO, false, 2000),
        touch_happy_button_(TOUCH_HAPPY_GPIO, true),
        touch_sad_button_(TOUCH_SAD_GPIO, true) {

        // Set Nepal timezone immediately at boot
        setenv("TZ", "UTC-5:45", 1);
        tzset();

        InitializeDisplayI2c();
        InitializeSsd1306Display();
        InitializeButtons();
        InitializeTouchSensors();
        InitializeSleepButton();
        InitializeTools();
        // Restore volume from NVS (saved on previous run)
        // First boot ever → defaults to 100 and saves it
        {
            Settings settings("luna", true);
            int saved = settings.GetInt("volume", 100);
            if (saved < 10) saved = 100;   // treat very low as "never set"
            if (saved > 100) saved = 100;
            GetAudioCodec()->SetOutputVolume(saved);
            settings.SetInt("volume", saved); // ensure written on first boot
            saved_volume_ = saved;
            ESP_LOGI(TAG, "Volume restored: %d%%", saved);
        }
        InitializeBattery();

        ESP_LOGI(TAG, "LUNA board ready! Nepal TZ set.");
    }

    virtual Led* GetLed() override {
        return &rgb_led_;
    }

    virtual AudioCodec* GetAudioCodec() override {
#ifdef AUDIO_I2S_METHOD_SIMPLEX
        static NoAudioCodecSimplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_SPK_GPIO_BCLK, AUDIO_I2S_SPK_GPIO_LRCK,
            AUDIO_I2S_SPK_GPIO_DOUT,
            AUDIO_I2S_MIC_GPIO_SCK, AUDIO_I2S_MIC_GPIO_WS,
            AUDIO_I2S_MIC_GPIO_DIN);
#else
        static NoAudioCodecDuplex audio_codec(
            AUDIO_INPUT_SAMPLE_RATE, AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_BCLK, AUDIO_I2S_GPIO_WS,
            AUDIO_I2S_GPIO_DOUT, AUDIO_I2S_GPIO_DIN);
#endif
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return display_;
    }

    // ============================================================
    // Hook into network event callback to start NTP after WiFi
    // ============================================================
    virtual void SetNetworkEventCallback(NetworkEventCallback callback) override {
        // Wrap the callback to intercept Connected event
        WifiBoard::SetNetworkEventCallback(
            [this, callback](NetworkEvent event, const std::string& data) {
                // Start NTP when WiFi connects
                if (event == NetworkEvent::Connected) {
                    StartNTP();
                }
                // Always call original callback too
                if (callback) {
                    callback(event, data);
                }
            }
        );
    }
};

DECLARE_BOARD(CompactWifiBoard);