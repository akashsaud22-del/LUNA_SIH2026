#pragma once

// ============================================================
// LUNA RGB Status LED — rgb_status_led.h
//
// Place in: main/boards/bread-compact-wifi/
//
// Drives a common-cathode RGB LED on 3 plain GPIO pins.
// No WS2812/RMT needed — just gpio_set_level().
//
// Behavior:
//   Boot test    → R → G → B flash once (confirms wiring)
//   Idle/Standby → BLUE solid
//   Listening    → RED solid
//   Speaking     → GREEN solid
//   Starting     → BLUE fast blink
//   WiFi config  → BLUE slow blink
//   Battery ≤20% → ALL OFF
// ============================================================

#include "led/led.h"
#include <driver/gpio.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <mutex>

class RgbStatusLed : public Led {
public:
    RgbStatusLed(gpio_num_t red_pin, gpio_num_t green_pin, gpio_num_t blue_pin);
    ~RgbStatusLed();

    // Called automatically by Application on every device state change
    virtual void OnStateChanged() override;

    // Called from battery monitor callback in compact_wifi_board.cc
    void SetBatteryLow(bool low);

private:
    gpio_num_t red_pin_;
    gpio_num_t green_pin_;
    gpio_num_t blue_pin_;

    bool battery_low_  = false;
    bool show_red_     = false;
    bool show_green_   = false;
    bool show_blue_    = false;

    // Instance-level blink toggle (NOT static — avoids shared state bug)
    bool blink_phase_  = false;

    esp_timer_handle_t blink_timer_ = nullptr;
    std::mutex mutex_;

    void SetPins(bool r, bool g, bool b);
    void TurnOn();
    void TurnOff();
    void StartBlink(int interval_ms);
    void StopBlink();

    static void BlinkTimerCallback(void* arg);
};