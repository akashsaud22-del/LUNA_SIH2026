#ifndef _BOARD_CONFIG_H_
#define _BOARD_CONFIG_H_

#include <driver/gpio.h>

// ============================================================
// LUNA AI Chatbot — Board Config
// Board: 7SEMI ESP32-S3-WROOM-1 N8R8
// ============================================================

#define AUDIO_INPUT_SAMPLE_RATE  16000
#define AUDIO_OUTPUT_SAMPLE_RATE 24000

// Simplex mode — separate pins for mic and speaker
#define AUDIO_I2S_METHOD_SIMPLEX

#ifdef AUDIO_I2S_METHOD_SIMPLEX

// INMP441 Microphone
#define AUDIO_I2S_MIC_GPIO_WS   GPIO_NUM_9
#define AUDIO_I2S_MIC_GPIO_SCK  GPIO_NUM_10
#define AUDIO_I2S_MIC_GPIO_DIN  GPIO_NUM_11

// MAX98357 Amplifier
#define AUDIO_I2S_SPK_GPIO_DOUT GPIO_NUM_7
#define AUDIO_I2S_SPK_GPIO_BCLK GPIO_NUM_15
#define AUDIO_I2S_SPK_GPIO_LRCK GPIO_NUM_16

#else

#define AUDIO_I2S_GPIO_WS   GPIO_NUM_9
#define AUDIO_I2S_GPIO_BCLK GPIO_NUM_10
#define AUDIO_I2S_GPIO_DIN  GPIO_NUM_11
#define AUDIO_I2S_GPIO_DOUT GPIO_NUM_7

#endif

// ============================================================
// BUTTONS
// ============================================================
#define BUILTIN_LED_GPIO        GPIO_NUM_48  // Onboard LED
#define BOOT_BUTTON_GPIO        GPIO_NUM_0   // Built-in boot button

// Mode toggle button (GPIO4) — your push button
// Press: toggle TEXT mode on/off
#define TOUCH_BUTTON_GPIO       GPIO_NUM_4

// ============================================================
// KY-040 ROTARY ENCODER
// Physical wiring:
//   KY-040 CLK → GPIO40
//   KY-040 DT  → GPIO39
//   KY-040 SW  → GPIO13  ← PUSH BUTTON (added!)
//   KY-040 VCC → 3.3V
//   KY-040 GND → GND
//
// How it works:
//   Rotate LEFT  → scroll text UP   (volume down pin)
//   Rotate RIGHT → scroll text DOWN (volume up pin)
//   PUSH/CLICK   → toggle TEXT mode (same as TOUCH_BUTTON)
// ============================================================
#define VOLUME_UP_BUTTON_GPIO   GPIO_NUM_40  // Encoder CLK → scroll RIGHT/DOWN
#define VOLUME_DOWN_BUTTON_GPIO GPIO_NUM_39  // Encoder DT  → scroll LEFT/UP
#define ENCODER_SW_GPIO         GPIO_NUM_13  // Encoder SW  → push to toggle mode

// ============================================================
// OLED DISPLAY (1.3" SH1106)
// Physical wiring:
//   OLED SDA → GPIO5
//   OLED SCL → GPIO6
//   OLED VCC → 3.3V
//   OLED GND → GND
// ============================================================
#define DISPLAY_SDA_PIN GPIO_NUM_5
#define DISPLAY_SCL_PIN GPIO_NUM_6
#define DISPLAY_WIDTH   128

#if CONFIG_OLED_SSD1306_128X32
#define DISPLAY_HEIGHT  32
#elif CONFIG_OLED_SSD1306_128X64
#define DISPLAY_HEIGHT  64
#elif CONFIG_OLED_SH1106_128X64
#define DISPLAY_HEIGHT  64
#define SH1106
#else
#error "OLED display type is not selected in menuconfig!"
#endif

#define DISPLAY_MIRROR_X true
#define DISPLAY_MIRROR_Y true

// MCP lamp test pin
#define LAMP_GPIO GPIO_NUM_18

// ============================================================
// EXTERNAL RGB STATUS LED
// Physical wiring (common cathode RGB LED):
//   LED GND  → ESP32 GND
//   LED R    → GPIO41  (Red)
//   LED G    → GPIO42  (Green)
//   LED B    → GPIO2   (Blue)
// ============================================================
#define RGB_RED_GPIO    GPIO_NUM_41
#define RGB_GREEN_GPIO  GPIO_NUM_42
#define RGB_BLUE_GPIO   GPIO_NUM_2

// ============================================================
// BATTERY VOLTAGE SENSOR
// Physical wiring:
//   Sensor green terminal (+/-) → Battery + / Battery -
//   Sensor "-" pin → ESP32 GND
//   Sensor "+" pin → ESP32 3.3V
//   Sensor "S" pin → ESP32 GPIO1   (ADC1_CH0)
// ============================================================
#define BATTERY_ADC_GPIO GPIO_NUM_1

// ============================================================
// TTP223 TOUCH SENSORS (LUNA)
// Physical wiring (each module: VCC->3.3V, GND->GND, OUT->pin below):
//   Sensor 1 OUT → GPIO3   "Happy" touch
//   Sensor 2 OUT → GPIO8   "Sad / Crying" touch
//
// NOTE: Sensor 2 (Sad/Crying) is currently DISABLED in code due
// to a freeze bug. The pin define is kept here in case this
// feature is revisited later — TOUCH_SAD_GPIO is not referenced
// anywhere else right now.
// ============================================================
#define TOUCH_HAPPY_GPIO   GPIO_NUM_3
#define TOUCH_SAD_GPIO     GPIO_NUM_8

// ============================================================
// SLEEP MODE BUTTON (LUNA) — "SELECT BTN" in the component list
// Hold 2 seconds to toggle between Normal Mode and Sleep Mode.
// GPIO13 (encoder push) is UNCHANGED — it still cycles the 3
// screens (Idle/Face/Text) exactly as before, in both modes.
// ============================================================
#define SLEEP_BUTTON_GPIO  GPIO_NUM_12

#endif // _BOARD_CONFIG_H_